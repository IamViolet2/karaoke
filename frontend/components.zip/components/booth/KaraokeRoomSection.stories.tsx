import React from 'react';
import { AttractScreen } from "./AttractScreen";
import { BoothKeypad } from "./BoothKeypad";
import { SessionStrip } from "./SessionStrip";

export default {
  title: 'Booth/KaraokeRoomSection',
  component: KaraokeRoomSection,
};

export const Default = () => <KaraokeRoomSection />;